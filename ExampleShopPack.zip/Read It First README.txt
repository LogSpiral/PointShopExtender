You can add specific expansion content for shops by using folders, allowing you to create custom expansion packs for the point shop system and share them with friends to try out!
Simply package the folder into a ZIP file and send it out when ready.

An expansion pack can include three components:

The Shops folder (most important): Add new items or goods here. Refer to the examples provided in this folder for formatting guidelines.

The Conditions folder: Use this to define custom unlock conditions (optional).

The Environments folder: Customize shop environments or themes here (optional).

Note:

Only files within these three folders will be loaded. Files placed outside them will be ignored.

All configuration files use YAML format, which can be opened with Notepad. However, we strongly recommend editing them with VS Code, as YAML files are sensitive to indentation and syntax.

This guide intentionally avoids Markdown formatting (probably to accommodate users who are hesitant to click on unfamiliar file extensions?).